# Kriti Dev to Unicode

a simple, stand-alone Node JS script that converts to and from Kruti Dev and Unicode

## Usage

1. Put your input text into the `input.txt`.
2. In `kritidevtounicode.js`, if you are converting from Kriti Dev, define `var begin = 0` in line 1; otherwise, define `var begin = 1`
3. In terminal, run `node kritidevltounicode.js`
4. Receive output in `output.txt`
